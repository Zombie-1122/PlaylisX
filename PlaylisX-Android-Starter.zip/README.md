# PlaylisX

PlaylisX is a lightweight Android M3U/M3U8 playlist editor built with Kotlin and Jetpack Compose. It is intended for playlists you own or are authorized to modify.

## Features in this starter

- Fetch a playlist from an HTTP(S) URL
- Import a local file using Android's document picker
- Find and replace text, with optional case-insensitive matching
- Add or update the `url-tvg` attribute in the `#EXTM3U` header
- Add an optional custom comment to the playlist
- Basic playlist validation and duplicate-candidate detection
- Undo recent in-memory edits
- Save/load one local cleanup profile
- Keep a small local activity history
- Preview and export an M3U playlist
- Black-and-gold UI
- GitHub Actions debug APK build

## Project structure

```text
PlaylisX/
├── .github/
│   └── workflows/
│       └── android.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/playlisx/app/
│           ├── MainActivity.kt
│           └── M3uProcessor.kt
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts
└── README.md
```

## Build an APK on GitHub (phone-friendly)

1. Create a **public** repository named `PlaylisX` on GitHub.
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build PlaylisX APK** using **Run workflow**, or push a commit to `main`.
5. Open the completed workflow run and scroll to **Artifacts**.
6. Download `PlaylisX-debug-apk`; extract it and install `app-debug.apk` on Android. You may need to allow installation from your browser or file manager.

## Build locally

Requirements: JDK 17, Android SDK Platform 35, and Gradle 8.11.1.

```bash
gradle --no-daemon assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Important notes

- This starter uses a debug APK. It is suitable for testing, not a production release.
- For a release APK, configure Android signing with GitHub Actions secrets. Never commit signing keys or passwords.
- The URL fetcher supports HTTP(S), but HTTPS is recommended. Only fetch URLs you trust; a remote playlist can be large or contain maliciously crafted text.
- The editor does not bypass DRM, authentication, access controls, or subscription requirements.
- The validator is a lightweight heuristic, not a full IPTV-player compatibility test.
- Duplicate detection is a candidate count, not a guaranteed list of duplicate channels.
- EPG metadata is written to the playlist header. It does not download or merge EPG programme data.
- Custom messages are added as M3U comments; IPTV apps may not display them in their UI.
- For large playlists, consider adding streaming parsing, a size limit, a richer diff preview, and automated unit tests before public release.

## License

MIT. See `LICENSE`.
