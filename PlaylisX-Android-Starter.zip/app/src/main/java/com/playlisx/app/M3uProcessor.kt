package com.playlisx.app

data class ValidationReport(
    val errors: List<String>,
    val warnings: List<String>,
    val channelCount: Int,
    val duplicateCount: Int
)

object M3uProcessor {
    fun ensureHeader(text: String): String {
        val trimmed = text.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        return if (trimmed.startsWith("#EXTM3U")) text else "#EXTM3U\n${text.trimStart()}"
    }

    fun replaceText(text: String, find: String, replacement: String, ignoreCase: Boolean): String {
        if (find.isEmpty()) return text
        return if (ignoreCase) text.replace(Regex(Regex.escape(find), RegexOption.IGNORE_CASE), replacement)
        else text.replace(find, replacement)
    }

    fun setEpgUrl(text: String, epgUrl: String): String {
        val url = epgUrl.trim()
        if (url.isEmpty()) return text
        val safeUrl = url.replace("\"", "%22")
        val lines = ensureHeader(text).lines().toMutableList()
        val headerIndex = lines.indexOfFirst { it.trimStart().startsWith("#EXTM3U") }
        if (headerIndex >= 0) {
            val header = lines[headerIndex]
            val withoutOld = header.replace(Regex("""\s+url-tvg\s*=\s*["'][^"']*["']""", RegexOption.IGNORE_CASE), "")
            lines[headerIndex] = withoutOld.trimEnd() + " url-tvg=\"$safeUrl\""
        }
        return lines.joinToString("\n")
    }

    fun addComment(text: String, message: String): String {
        val cleanMessage = message.trim().replace("\r", " ").replace("\n", " ")
        if (cleanMessage.isEmpty()) return ensureHeader(text)
        val lines = ensureHeader(text).lines().toMutableList()
        val header = lines.indexOfFirst { it.trimStart().startsWith("#EXTM3U") }
        lines.add(if (header >= 0) header + 1 else 0, "# PlaylisX: $cleanMessage")
        return lines.joinToString("\n")
    }

    fun validate(text: String): ValidationReport {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        val lines = text.lines()
        if (lines.none { it.trim().startsWith("#EXTM3U") }) errors += "Missing #EXTM3U header."
        val extinfIndices = lines.indices.filter { lines[it].trimStart().startsWith("#EXTINF:") }
        var missingUrl = 0
        for (idx in extinfIndices) {
            val nextContent = lines.drop(idx + 1).firstOrNull { it.isNotBlank() && !it.trimStart().startsWith("#") }
            if (nextContent == null) missingUrl++
        }
        if (missingUrl > 0) warnings += "$missingUrl channel entr(y/ies) have no stream URL."
        val malformed = lines.count { it.trimStart().startsWith("#EXTINF:") && !it.contains(",") }
        if (malformed > 0) warnings += "$malformed #EXTINF line(s) have no comma/name separator."
        val urls = lines.filter { it.isNotBlank() && !it.trimStart().startsWith("#") }
        val duplicates = urls.groupingBy { it.trim() }.eachCount().filterValues { it > 1 }.size
        if (duplicates > 0) warnings += "$duplicates duplicated stream URL(s) detected."
        val channelNames = extinfIndices.map { idx -> lines[idx].substringAfterLast(",").trim().lowercase() }
        val duplicateNames = channelNames.groupingBy { it }.eachCount().filterValues { it > 1 }.size
        return ValidationReport(errors, warnings, extinfIndices.size, duplicateNames.coerceAtLeast(duplicates))
    }

    fun channelCount(text: String) = text.lines().count { it.trimStart().startsWith("#EXTINF:") }

    fun preview(text: String, maxLines: Int = 80): String =
        text.lines().take(maxLines).joinToString("\n")
}
