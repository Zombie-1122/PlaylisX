package com.playlisx.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private val Gold = Color(0xFFFFD54F)
private val Background = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Muted = Color(0xFFB8BBC4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PlaylisXApp() }
    }
}

@Composable
private fun PlaylisXApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("playlisx", Context.MODE_PRIVATE) }

    var playlist by remember { mutableStateOf("") }
    var sourceUrl by remember { mutableStateOf("") }
    var findText by remember { mutableStateOf("") }
    var replaceText by remember { mutableStateOf("") }
    var epgUrl by remember { mutableStateOf(prefs.getString("epg", "") ?: "") }
    var customMessage by remember { mutableStateOf(prefs.getString("message", "") ?: "") }
    var status by remember { mutableStateOf("Import a playlist or fetch a URL to begin.") }
    var busy by remember { mutableStateOf(false) }
    var ignoreCase by remember { mutableStateOf(true) }
    var undoStack by remember { mutableStateOf(listOf<String>()) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    var profileName by remember { mutableStateOf("My cleanup profile") }
    var profileSaved by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<ValidationReport?>(null) }

    fun rememberChange() {
        if (playlist.isNotEmpty()) undoStack = (undoStack + playlist).takeLast(20)
    }
    fun recordHistory(label: String) {
        val entry = "${System.currentTimeMillis()} | $label"
        history = (listOf(entry) + history.lines().filter { it.isNotBlank() }).take(10).joinToString("\n")
        prefs.edit().putString("history", history).apply()
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.onSuccess { text ->
                if (text != null) {
                    rememberChange()
                    playlist = text
                    report = null
                    status = "Imported ${uri.lastPathSegment ?: "file"}"
                    recordHistory("Imported local file")
                } else status = "Could not read that file."
            }.onFailure { status = "Import failed: ${it.message ?: "unknown error"}" }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(playlist) }
                    ?: error("Unable to open destination")
            }.onSuccess {
                status = "Playlist exported successfully."
                recordHistory("Exported playlist")
            }.onFailure { status = "Export failed: ${it.message ?: "unknown error"}" }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = Background, background = Background,
            surface = Panel, onSurface = Color.White, secondary = Gold
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Background).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(48.dp).background(Gold, MaterialTheme.shapes.medium), contentAlignment = Alignment.Center) {
                    Text("▶", color = Background, fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
                Column(Modifier.weight(1f)) {
                    Text("PlaylisX", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("IPTV PLAYLIST TOOLKIT", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Text("v1.0", color = Muted, fontSize = 12.sp)
            }

            CardBlock("01  IMPORT PLAYLIST") {
                Text("Fetch an authorized M3U/M3U8 URL or open a local file.", color = Muted, fontSize = 13.sp)
                TextEntry(sourceUrl, { sourceUrl = it }, "https://example.com/playlist.m3u")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ButtonX("Fetch URL", Modifier.weight(1f), enabled = !busy && sourceUrl.isNotBlank()) {
                        scope.launch {
                            busy = true
                            status = "Fetching playlist…"
                            try {
                                val result = withContext(Dispatchers.IO) {
                                    val url = URL(sourceUrl.trim())
                                    require(url.protocol == "https" || url.protocol == "http") { "Only HTTP(S) URLs are supported." }
                                    val connection = (url.openConnection() as HttpURLConnection).apply {
                                        connectTimeout = 12000
                                        readTimeout = 20000
                                        instanceFollowRedirects = true
                                        setRequestProperty("User-Agent", "PlaylisX/1.0")
                                    }
                                    try {
                                        require(connection.responseCode in 200..299) { "Server returned HTTP ${connection.responseCode}" }
                                        connection.inputStream.bufferedReader().use { it.readText() }
                                    } finally { connection.disconnect() }
                                }
                                rememberChange()
                                playlist = result
                                report = null
                                status = "Playlist fetched."
                                recordHistory("Fetched URL")
                            } catch (e: Exception) {
                                status = "Fetch failed: ${e.message ?: "check the URL"}"
                            } finally { busy = false }
                        }
                    }
                    OutlinedButton(
                        onClick = { importLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                    ) { Text("Import file") }
                }
            }

            CardBlock("02  CLEANUP RULES") {
                TextEntry(findText, { findText = it }, "Text to find")
                TextEntry(replaceText, { replaceText = it }, "Replace with (empty removes it)")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = ignoreCase, onCheckedChange = { ignoreCase = it }, colors = CheckboxDefaults.colors(checkedColor = Gold))
                    Text("Ignore letter case", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    ButtonX("Replace", enabled = playlist.isNotEmpty() && findText.isNotEmpty()) {
                        rememberChange()
                        playlist = M3uProcessor.replaceText(playlist, findText, replaceText, ignoreCase)
                        report = null
                        status = "Find-and-replace applied."
                        recordHistory("Applied text replacement")
                    }
                }
                Text("Only edit playlists you own or are authorized to modify.", color = Muted, fontSize = 11.sp)
            }

            CardBlock("03  EPG & CUSTOM MESSAGE") {
                TextEntry(epgUrl, { epgUrl = it; prefs.edit().putString("epg", it).apply() }, "XMLTV / TVG URL (optional)")
                TextEntry(customMessage, { customMessage = it; prefs.edit().putString("message", it).apply() }, "Optional playlist comment")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ButtonX("Apply EPG URL", Modifier.weight(1f), enabled = playlist.isNotEmpty() && epgUrl.isNotBlank()) {
                        rememberChange()
                        playlist = M3uProcessor.setEpgUrl(playlist, epgUrl)
                        status = "EPG URL applied to #EXTM3U header."
                        recordHistory("Updated EPG URL")
                    }
                    ButtonX("Add message", Modifier.weight(1f), enabled = playlist.isNotEmpty() && customMessage.isNotBlank()) {
                        rememberChange()
                        playlist = M3uProcessor.addComment(playlist, customMessage)
                        status = "Custom comment added."
                        recordHistory("Added custom comment")
                    }
                }
            }

            CardBlock("04  CHECK PLAYLIST") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ButtonX("Validate", Modifier.weight(1f), enabled = playlist.isNotEmpty()) {
                        report = M3uProcessor.validate(playlist)
                        status = "Validation complete."
                    }
                    OutlinedButton(
                        onClick = {
                            val r = M3uProcessor.validate(playlist)
                            report = r
                            status = "${r.duplicateCount} possible duplicate(s) found."
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold),
                        enabled = playlist.isNotEmpty()
                    ) { Text("Find duplicates") }
                }
                report?.let { r ->
                    Text("Channels: ${r.channelCount}  •  Duplicate candidates: ${r.duplicateCount}", color = Gold, fontWeight = FontWeight.SemiBold)
                    (r.errors + r.warnings).ifEmpty { listOf("No basic structural issues detected.") }.forEach {
                        Text("• $it", color = if (r.errors.isNotEmpty() && r.errors.contains(it)) Color(0xFFFF8A80) else Muted, fontSize = 13.sp)
                    }
                }
            }

            CardBlock("05  PROFILES & HISTORY") {
                TextEntry(profileName, { profileName = it }, "Profile name")
                ButtonX(if (profileSaved) "Profile saved locally" else "Save current rules as profile", enabled = true) {
                    prefs.edit().putString("profileName", profileName).putString("find", findText)
                        .putString("replace", replaceText).putBoolean("ignoreCase", ignoreCase).apply()
                    profileSaved = true
                    status = "Saved profile: $profileName"
                }
                Text("Recent activity", color = Gold, fontWeight = FontWeight.SemiBold)
                Text(history.ifBlank { "No activity yet." }, color = Muted, fontSize = 12.sp)
                OutlinedButton(
                    onClick = {
                        val savedName = prefs.getString("profileName", null)
                        if (savedName != null) {
                            profileName = savedName
                            findText = prefs.getString("find", "") ?: ""
                            replaceText = prefs.getString("replace", "") ?: ""
                            ignoreCase = prefs.getBoolean("ignoreCase", true)
                            profileSaved = true
                            status = "Loaded profile: $savedName"
                        } else status = "Save a profile first."
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                ) { Text("Load saved profile") }
            }

            CardBlock("06  PREVIEW & EXPORT") {
                Text("Current playlist: ${M3uProcessor.channelCount(playlist)} channels • ${playlist.length} characters", color = Muted, fontSize = 12.sp)
                Text(
                    M3uProcessor.preview(playlist).ifBlank { "Your playlist preview will appear here." },
                    color = Color(0xFFE5E5E5), fontSize = 11.sp, lineHeight = 15.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (undoStack.isNotEmpty()) {
                                playlist = undoStack.last()
                                undoStack = undoStack.dropLast(1)
                                report = null
                                status = "Last change undone."
                            } else status = "Nothing to undo."
                        },
                        modifier = Modifier.weight(1f),
                        enabled = undoStack.isNotEmpty(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                    ) { Text("Undo") }
                    ButtonX("Export M3U", Modifier.weight(1f), enabled = playlist.isNotBlank()) {
                        exportLauncher.launch("PlaylisX-playlist.m3u")
                    }
                }
            }

            Text(status, color = Gold, fontSize = 12.sp)
            Text("PlaylisX is a playlist editor, not a stream provider. Use lawful sources and respect content rights.", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun CardBlock(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = MaterialTheme.shapes.large) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            content()
        }
    }
}

@Composable
private fun TextEntry(value: String, onValueChange: (String) -> Unit, placeholder: String) {
    Column(Modifier.fillMaxWidth().background(Background, MaterialTheme.shapes.medium).padding(horizontal = 12.dp, vertical = 10.dp)) {
        if (value.isEmpty()) {
            BasicTextField(
                value = value, onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                singleLine = true,
                decorationBox = { inner ->
                    Box {
                        if (value.isEmpty()) Text(placeholder, color = Muted, fontSize = 14.sp)
                        inner()
                    }
                }
            )
        } else {
            BasicTextField(
                value = value, onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                singleLine = true
            )
        }
    }
}

@Composable
private fun ButtonX(
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Background),
        shape = MaterialTheme.shapes.medium
    ) { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
}
